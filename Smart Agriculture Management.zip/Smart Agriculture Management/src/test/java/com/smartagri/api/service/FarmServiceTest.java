package com.smartagri.api.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.smartagri.api.model.Equipment;
import com.smartagri.api.model.Farm;
import com.smartagri.api.repository.CropRepository;
import com.smartagri.api.repository.EquipmentRepository;
import com.smartagri.api.repository.FarmRepository;
import com.smartagri.api.repository.FarmerRepository;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class FarmServiceTest {

    @Mock
    private FarmRepository farmRepository;

    @Mock
    private FarmerRepository farmerRepository;

    @Mock
    private CropRepository cropRepository;

    @Mock
    private EquipmentRepository equipmentRepository;

    @InjectMocks
    private FarmService farmService;

    @Test
    void assignEquipmentShouldInitializeMissingListsAndSyncBothSides() {
        Farm farm = new Farm();
        farm.setId("farm-1");
        farm.setEquipmentIds(null);

        Equipment equipment = new Equipment();
        equipment.setId("equipment-1");
        equipment.setFarmIds(null);

        when(farmRepository.findById("farm-1")).thenReturn(Optional.of(farm));
        when(equipmentRepository.findById("equipment-1")).thenReturn(Optional.of(equipment));
        when(equipmentRepository.save(any(Equipment.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(farmRepository.save(any(Farm.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Farm updatedFarm = farmService.assignEquipment("farm-1", "equipment-1");

        assertEquals(List.of("equipment-1"), updatedFarm.getEquipmentIds());
        assertEquals(List.of("farm-1"), equipment.getFarmIds());
    }

    @Test
    void deleteShouldRemoveFarmIdFromLinkedEquipmentBeforeDeletingFarm() {
        Farm farm = new Farm();
        farm.setId("farm-1");

        Equipment equipment = new Equipment();
        equipment.setId("equipment-1");
        equipment.setFarmIds(new ArrayList<>(List.of("farm-1", "farm-2")));

        when(farmRepository.findById("farm-1")).thenReturn(Optional.of(farm));
        when(cropRepository.existsByFarmId("farm-1")).thenReturn(false);
        when(equipmentRepository.findByFarmIdsContaining("farm-1")).thenReturn(List.of(equipment));

        farmService.delete("farm-1");

        assertFalse(equipment.getFarmIds().contains("farm-1"));
        assertEquals(List.of("farm-2"), equipment.getFarmIds());
        verify(equipmentRepository).save(equipment);
        verify(farmRepository).delete(farm);
    }
}
