package com.smartagri.api.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.smartagri.api.dto.FarmerRequest;
import com.smartagri.api.exception.ConflictException;
import com.smartagri.api.model.Farmer;
import com.smartagri.api.repository.FarmRepository;
import com.smartagri.api.repository.FarmerRepository;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class FarmerServiceTest {

    @Mock
    private FarmerRepository farmerRepository;

    @Mock
    private FarmRepository farmRepository;

    @InjectMocks
    private FarmerService farmerService;

    @Test
    void createShouldTrimIncomingFieldsBeforeSaving() {
        FarmerRequest request = new FarmerRequest("  Ramesh  ", " 9876543210 ", " Warangal ");

        when(farmerRepository.save(any(Farmer.class))).thenAnswer(invocation -> {
            Farmer farmer = invocation.getArgument(0);
            farmer.setId("farmer-1");
            return farmer;
        });

        Farmer farmer = farmerService.create(request);

        assertEquals("farmer-1", farmer.getId());
        assertEquals("Ramesh", farmer.getName());
        assertEquals("9876543210", farmer.getContactNumber());
        assertEquals("Warangal", farmer.getAddress());
    }

    @Test
    void deleteShouldThrowConflictWhenFarmsAreLinked() {
        Farmer farmer = new Farmer();
        farmer.setId("farmer-1");

        when(farmerRepository.findById("farmer-1")).thenReturn(Optional.of(farmer));
        when(farmRepository.existsByFarmerId("farmer-1")).thenReturn(true);

        ConflictException exception = assertThrows(
                ConflictException.class,
                () -> farmerService.delete("farmer-1")
        );

        assertEquals("Cannot delete farmer because farms are linked to this farmer.", exception.getMessage());
        verify(farmerRepository, never()).delete(any(Farmer.class));
    }
}
