package com.smartagri.api.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.smartagri.api.dto.HarvestRequest;
import com.smartagri.api.exception.ResourceNotFoundException;
import com.smartagri.api.model.HarvestRecord;
import com.smartagri.api.repository.CropRepository;
import com.smartagri.api.repository.HarvestRecordRepository;
import java.time.LocalDate;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class HarvestRecordServiceTest {

    @Mock
    private HarvestRecordRepository harvestRecordRepository;

    @Mock
    private CropRepository cropRepository;

    @InjectMocks
    private HarvestRecordService harvestRecordService;

    @Test
    void createShouldTrimProductionRecordBeforeSaving() {
        HarvestRequest request = new HarvestRequest(
                " crop-1 ",
                3200.0,
                LocalDate.of(2026, 6, 18),
                " Successful harvest "
        );

        when(cropRepository.existsById("crop-1")).thenReturn(true);
        when(harvestRecordRepository.save(any(HarvestRecord.class))).thenAnswer(invocation -> {
            HarvestRecord harvestRecord = invocation.getArgument(0);
            harvestRecord.setId("harvest-1");
            return harvestRecord;
        });

        HarvestRecord harvestRecord = harvestRecordService.create(request);

        assertEquals("harvest-1", harvestRecord.getId());
        assertEquals("crop-1", harvestRecord.getCropId());
        assertEquals("Successful harvest", harvestRecord.getProductionRecord());
    }

    @Test
    void getByCropIdShouldThrowWhenCropDoesNotExist() {
        when(cropRepository.existsById("missing-crop")).thenReturn(false);

        ResourceNotFoundException exception = assertThrows(
                ResourceNotFoundException.class,
                () -> harvestRecordService.getByCropId("missing-crop")
        );

        assertEquals("Crop not found with id: missing-crop", exception.getMessage());
    }
}
