package com.smartagri.api.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.smartagri.api.dto.CropRequest;
import com.smartagri.api.exception.ConflictException;
import com.smartagri.api.model.Crop;
import com.smartagri.api.repository.CropRepository;
import com.smartagri.api.repository.FarmRepository;
import com.smartagri.api.repository.HarvestRecordRepository;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class CropServiceTest {

    @Mock
    private CropRepository cropRepository;

    @Mock
    private FarmRepository farmRepository;

    @Mock
    private HarvestRecordRepository harvestRecordRepository;

    @InjectMocks
    private CropService cropService;

    @Test
    void createShouldTrimFieldsBeforeSaving() {
        CropRequest request = new CropRequest(" farm-1 ", " Rice ", " Kharif ", " Growing ", 2500.0);

        when(farmRepository.existsById("farm-1")).thenReturn(true);
        when(cropRepository.save(any(Crop.class))).thenAnswer(invocation -> {
            Crop crop = invocation.getArgument(0);
            crop.setId("crop-1");
            return crop;
        });

        Crop crop = cropService.create(request);

        assertEquals("crop-1", crop.getId());
        assertEquals("farm-1", crop.getFarmId());
        assertEquals("Rice", crop.getCropName());
        assertEquals("Kharif", crop.getSeason());
        assertEquals("Growing", crop.getCultivationStatus());
        assertEquals(2500.0, crop.getExpectedYield());
    }

    @Test
    void deleteShouldThrowConflictWhenHarvestRecordsExist() {
        Crop crop = new Crop();
        crop.setId("crop-1");

        when(cropRepository.findById("crop-1")).thenReturn(Optional.of(crop));
        when(harvestRecordRepository.existsByCropId("crop-1")).thenReturn(true);

        ConflictException exception = assertThrows(
                ConflictException.class,
                () -> cropService.delete("crop-1")
        );

        assertEquals("Cannot delete crop because harvest records are linked to this crop.", exception.getMessage());
        verify(cropRepository, never()).delete(any(Crop.class));
    }
}
