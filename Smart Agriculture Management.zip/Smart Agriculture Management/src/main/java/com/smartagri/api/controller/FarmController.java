package com.smartagri.api.controller;

import com.smartagri.api.dto.FarmRequest;
import com.smartagri.api.model.Crop;
import com.smartagri.api.model.Equipment;
import com.smartagri.api.model.Farm;
import com.smartagri.api.service.FarmService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/farms")
@Tag(name = "Farms", description = "Operations related to farms")
public class FarmController {

    private final FarmService farmService;

    public FarmController(FarmService farmService) {
        this.farmService = farmService;
    }

    @PostMapping
    @Operation(summary = "Create a new farm")
    public ResponseEntity<Farm> create(@Valid @RequestBody FarmRequest request) {
        Farm farm = farmService.create(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(farm);
    }

    @GetMapping
    @Operation(summary = "Get all farms")
    public List<Farm> getAll() {
        return farmService.getAll();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get farm by ID")
    public Farm getById(@PathVariable String id) {
        return farmService.getById(id);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update farm by ID")
    public Farm update(@PathVariable String id, @Valid @RequestBody FarmRequest request) {
        return farmService.update(id, request);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete farm by ID")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        farmService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/farmer/{farmerId}")
    @Operation(summary = "Get farms by farmer ID")
    public List<Farm> getByFarmerId(@PathVariable String farmerId) {
        return farmService.getByFarmerId(farmerId);
    }

    @GetMapping("/{id}/crops")
    @Operation(summary = "Get crops belonging to a farm")
    public List<Crop> getCrops(@PathVariable String id) {
        return farmService.getCropsByFarmId(id);
    }

    @GetMapping("/{id}/equipment")
    @Operation(summary = "Get equipment assigned to a farm")
    public List<Equipment> getEquipment(@PathVariable String id) {
        return farmService.getEquipmentByFarmId(id);
    }

    @PostMapping("/{farmId}/equipment/{equipmentId}")
    @Operation(summary = "Assign equipment to a farm")
    public Farm assignEquipment(@PathVariable String farmId, @PathVariable String equipmentId) {
        return farmService.assignEquipment(farmId, equipmentId);
    }

    @DeleteMapping("/{farmId}/equipment/{equipmentId}")
    @Operation(summary = "Remove equipment from a farm")
    public Farm removeEquipment(@PathVariable String farmId, @PathVariable String equipmentId) {
        return farmService.removeEquipment(farmId, equipmentId);
    }
}
