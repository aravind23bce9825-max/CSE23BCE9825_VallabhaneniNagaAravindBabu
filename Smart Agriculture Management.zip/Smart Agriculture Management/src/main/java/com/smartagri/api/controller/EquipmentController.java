package com.smartagri.api.controller;

import com.smartagri.api.dto.EquipmentRequest;
import com.smartagri.api.model.Equipment;
import com.smartagri.api.service.EquipmentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/equipment")
@Tag(name = "Equipment", description = "Operations related to equipment")
public class EquipmentController {

    private final EquipmentService equipmentService;

    public EquipmentController(EquipmentService equipmentService) {
        this.equipmentService = equipmentService;
    }

    @PostMapping
    @Operation(summary = "Create new equipment")
    public ResponseEntity<Equipment> create(@Valid @RequestBody EquipmentRequest request) {
        Equipment equipment = equipmentService.create(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(equipment);
    }

    @GetMapping
    @Operation(summary = "Get all equipment")
    public List<Equipment> getAll() {
        return equipmentService.getAll();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get equipment by ID")
    public Equipment getById(@PathVariable String id) {
        return equipmentService.getById(id);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update equipment by ID")
    public Equipment update(@PathVariable String id, @Valid @RequestBody EquipmentRequest request) {
        return equipmentService.update(id, request);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete equipment by ID")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        equipmentService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/farm/{farmId}")
    @Operation(summary = "Get equipment by farm ID")
    public List<Equipment> getByFarmId(@PathVariable String farmId) {
        return equipmentService.getByFarmId(farmId);
    }
}
