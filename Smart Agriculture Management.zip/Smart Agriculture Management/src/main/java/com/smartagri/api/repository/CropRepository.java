package com.smartagri.api.repository;

import com.smartagri.api.model.Crop;
import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface CropRepository extends MongoRepository<Crop, String> {

    List<Crop> findByFarmId(String farmId);

    boolean existsByFarmId(String farmId);
}

