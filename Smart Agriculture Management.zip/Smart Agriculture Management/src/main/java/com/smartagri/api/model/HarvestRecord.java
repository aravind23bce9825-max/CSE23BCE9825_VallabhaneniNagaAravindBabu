package com.smartagri.api.model;

import java.time.LocalDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "harvests")
public class HarvestRecord {

    @Id
    private String id;
    private String cropId;
    private Double quantity;
    private LocalDate harvestDate;
    private String productionRecord;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCropId() {
        return cropId;
    }

    public void setCropId(String cropId) {
        this.cropId = cropId;
    }

    public Double getQuantity() {
        return quantity;
    }

    public void setQuantity(Double quantity) {
        this.quantity = quantity;
    }

    public LocalDate getHarvestDate() {
        return harvestDate;
    }

    public void setHarvestDate(LocalDate harvestDate) {
        this.harvestDate = harvestDate;
    }

    public String getProductionRecord() {
        return productionRecord;
    }

    public void setProductionRecord(String productionRecord) {
        this.productionRecord = productionRecord;
    }
}

