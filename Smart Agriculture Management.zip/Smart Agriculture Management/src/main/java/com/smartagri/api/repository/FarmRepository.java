package com.smartagri.api.repository;

import com.smartagri.api.model.Farm;
import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface FarmRepository extends MongoRepository<Farm, String> {

    List<Farm> findByFarmerId(String farmerId);

    boolean existsByFarmerId(String farmerId);
}

