package com.smartagri.api.controller;

import com.smartagri.api.dto.CropRequest;
import com.smartagri.api.model.Crop;
import com.smartagri.api.model.HarvestRecord;
import com.smartagri.api.service.CropService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/crops")
@Tag(name = "Crops", description = "Operations related to crops")
public class CropController {

    private final CropService cropService;

    public CropController(CropService cropService) {
        this.cropService = cropService;
    }

    @PostMapping
    @Operation(summary = "Create a new crop")
    public ResponseEntity<Crop> create(@Valid @RequestBody CropRequest request) {
        Crop crop = cropService.create(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(crop);
    }

    @GetMapping
    @Operation(summary = "Get all crops")
    public List<Crop> getAll() {
        return cropService.getAll();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get crop by ID")
    public Crop getById(@PathVariable String id) {
        return cropService.getById(id);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update crop by ID")
    public Crop update(@PathVariable String id, @Valid @RequestBody CropRequest request) {
        return cropService.update(id, request);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete crop by ID")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        cropService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/farm/{farmId}")
    @Operation(summary = "Get crops by farm ID")
    public List<Crop> getByFarmId(@PathVariable String farmId) {
        return cropService.getByFarmId(farmId);
    }

    @GetMapping("/{id}/harvests")
    @Operation(summary = "Get harvest records belonging to a crop")
    public List<HarvestRecord> getHarvests(@PathVariable String id) {
        return cropService.getHarvestsByCropId(id);
    }
}
