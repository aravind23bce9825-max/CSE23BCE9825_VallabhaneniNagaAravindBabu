package com.smartagri.api.repository;

import com.smartagri.api.model.HarvestRecord;
import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface HarvestRecordRepository extends MongoRepository<HarvestRecord, String> {

    List<HarvestRecord> findByCropId(String cropId);

    boolean existsByCropId(String cropId);
}

