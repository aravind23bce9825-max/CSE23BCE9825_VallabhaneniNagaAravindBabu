package com.smartagri.api.service;

import com.smartagri.api.dto.CropRequest;
import com.smartagri.api.exception.ConflictException;
import com.smartagri.api.exception.ResourceNotFoundException;
import com.smartagri.api.model.Crop;
import com.smartagri.api.model.HarvestRecord;
import com.smartagri.api.repository.CropRepository;
import com.smartagri.api.repository.FarmRepository;
import com.smartagri.api.repository.HarvestRecordRepository;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class CropService {

    private final CropRepository cropRepository;
    private final FarmRepository farmRepository;
    private final HarvestRecordRepository harvestRecordRepository;

    public CropService(
            CropRepository cropRepository,
            FarmRepository farmRepository,
            HarvestRecordRepository harvestRecordRepository
    ) {
        this.cropRepository = cropRepository;
        this.farmRepository = farmRepository;
        this.harvestRecordRepository = harvestRecordRepository;
    }

    public Crop create(CropRequest request) {
        validateFarm(request.farmId());

        Crop crop = new Crop();
        crop.setFarmId(request.farmId().trim());
        crop.setCropName(request.cropName().trim());
        crop.setSeason(request.season().trim());
        crop.setCultivationStatus(request.cultivationStatus().trim());
        crop.setExpectedYield(request.expectedYield());
        return cropRepository.save(crop);
    }

    public List<Crop> getAll() {
        return cropRepository.findAll();
    }

    public Crop getById(String id) {
        return cropRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Crop not found with id: " + id));
    }

    public Crop update(String id, CropRequest request) {
        validateFarm(request.farmId());

        Crop crop = getById(id);
        crop.setFarmId(request.farmId().trim());
        crop.setCropName(request.cropName().trim());
        crop.setSeason(request.season().trim());
        crop.setCultivationStatus(request.cultivationStatus().trim());
        crop.setExpectedYield(request.expectedYield());
        return cropRepository.save(crop);
    }

    public void delete(String id) {
        Crop crop = getById(id);
        if (harvestRecordRepository.existsByCropId(id)) {
            throw new ConflictException("Cannot delete crop because harvest records are linked to this crop.");
        }
        cropRepository.delete(crop);
    }

    public List<Crop> getByFarmId(String farmId) {
        validateFarm(farmId);
        return cropRepository.findByFarmId(farmId);
    }

    public List<HarvestRecord> getHarvestsByCropId(String cropId) {
        getById(cropId);
        return harvestRecordRepository.findByCropId(cropId);
    }

    private void validateFarm(String farmId) {
        if (!farmRepository.existsById(farmId.trim())) {
            throw new ResourceNotFoundException("Farm not found with id: " + farmId);
        }
    }
}

