package com.smartagri.api.repository;

import com.smartagri.api.model.Equipment;
import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface EquipmentRepository extends MongoRepository<Equipment, String> {

    List<Equipment> findByFarmIdsContaining(String farmId);
}

