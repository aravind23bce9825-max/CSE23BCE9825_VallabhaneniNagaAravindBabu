package com.smartagri.api.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public record CropRequest(
        @NotBlank(message = "Farm ID is required")
        String farmId,
        @NotBlank(message = "Crop name is required")
        String cropName,
        @NotBlank(message = "Season is required")
        String season,
        @NotBlank(message = "Cultivation status is required")
        String cultivationStatus,
        @NotNull(message = "Expected yield is required")
        @Positive(message = "Expected yield must be greater than zero")
        Double expectedYield
) {
}

