package com.smartagri.api.controller;

import com.smartagri.api.dto.FarmerRequest;
import com.smartagri.api.model.Farm;
import com.smartagri.api.model.Farmer;
import com.smartagri.api.service.FarmerService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/farmers")
@Tag(name = "Farmers", description = "Operations related to farmers")
public class FarmerController {

    private final FarmerService farmerService;

    public FarmerController(FarmerService farmerService) {
        this.farmerService = farmerService;
    }

    @PostMapping
    @Operation(summary = "Create a new farmer")
    public ResponseEntity<Farmer> create(@Valid @RequestBody FarmerRequest request) {
        Farmer farmer = farmerService.create(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(farmer);
    }

    @GetMapping
    @Operation(summary = "Get all farmers")
    public List<Farmer> getAll() {
        return farmerService.getAll();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get farmer by ID")
    public Farmer getById(@PathVariable String id) {
        return farmerService.getById(id);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update farmer by ID")
    public Farmer update(@PathVariable String id, @Valid @RequestBody FarmerRequest request) {
        return farmerService.update(id, request);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete farmer by ID")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        farmerService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}/farms")
    @Operation(summary = "Get farms belonging to a farmer")
    public List<Farm> getFarms(@PathVariable String id) {
        return farmerService.getFarmsByFarmerId(id);
    }
}
