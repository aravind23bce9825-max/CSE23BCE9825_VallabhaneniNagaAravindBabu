package com.smartagri.api.dto;

import jakarta.validation.constraints.NotBlank;

public record FarmerRequest(
        @NotBlank(message = "Name is required")
        String name,
        @NotBlank(message = "Contact number is required")
        String contactNumber,
        @NotBlank(message = "Address is required")
        String address
) {
}

