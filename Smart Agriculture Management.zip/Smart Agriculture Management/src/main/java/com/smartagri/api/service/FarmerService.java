package com.smartagri.api.service;

import com.smartagri.api.dto.FarmerRequest;
import com.smartagri.api.exception.ConflictException;
import com.smartagri.api.exception.ResourceNotFoundException;
import com.smartagri.api.model.Farm;
import com.smartagri.api.model.Farmer;
import com.smartagri.api.repository.FarmRepository;
import com.smartagri.api.repository.FarmerRepository;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class FarmerService {

    private final FarmerRepository farmerRepository;
    private final FarmRepository farmRepository;

    public FarmerService(FarmerRepository farmerRepository, FarmRepository farmRepository) {
        this.farmerRepository = farmerRepository;
        this.farmRepository = farmRepository;
    }

    public Farmer create(FarmerRequest request) {
        Farmer farmer = new Farmer();
        farmer.setName(request.name().trim());
        farmer.setContactNumber(request.contactNumber().trim());
        farmer.setAddress(request.address().trim());
        return farmerRepository.save(farmer);
    }

    public List<Farmer> getAll() {
        return farmerRepository.findAll();
    }

    public Farmer getById(String id) {
        return farmerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Farmer not found with id: " + id));
    }

    public Farmer update(String id, FarmerRequest request) {
        Farmer farmer = getById(id);
        farmer.setName(request.name().trim());
        farmer.setContactNumber(request.contactNumber().trim());
        farmer.setAddress(request.address().trim());
        return farmerRepository.save(farmer);
    }

    public void delete(String id) {
        Farmer farmer = getById(id);
        if (farmRepository.existsByFarmerId(id)) {
            throw new ConflictException("Cannot delete farmer because farms are linked to this farmer.");
        }
        farmerRepository.delete(farmer);
    }

    public List<Farm> getFarmsByFarmerId(String farmerId) {
        getById(farmerId);
        return farmRepository.findByFarmerId(farmerId);
    }
}

