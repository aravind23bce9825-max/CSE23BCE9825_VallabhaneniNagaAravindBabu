package com.smartagri.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartAgricultureManagementApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(SmartAgricultureManagementApiApplication.class, args);
    }
}

