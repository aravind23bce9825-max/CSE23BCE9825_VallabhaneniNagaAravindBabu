package com.smartagri.api.service;

import com.smartagri.api.dto.HarvestRequest;
import com.smartagri.api.exception.ResourceNotFoundException;
import com.smartagri.api.model.HarvestRecord;
import com.smartagri.api.repository.CropRepository;
import com.smartagri.api.repository.HarvestRecordRepository;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class HarvestRecordService {

    private final HarvestRecordRepository harvestRecordRepository;
    private final CropRepository cropRepository;

    public HarvestRecordService(HarvestRecordRepository harvestRecordRepository, CropRepository cropRepository) {
        this.harvestRecordRepository = harvestRecordRepository;
        this.cropRepository = cropRepository;
    }

    public HarvestRecord create(HarvestRequest request) {
        validateCrop(request.cropId());

        HarvestRecord harvestRecord = new HarvestRecord();
        harvestRecord.setCropId(request.cropId().trim());
        harvestRecord.setQuantity(request.quantity());
        harvestRecord.setHarvestDate(request.harvestDate());
        harvestRecord.setProductionRecord(request.productionRecord().trim());
        return harvestRecordRepository.save(harvestRecord);
    }

    public List<HarvestRecord> getAll() {
        return harvestRecordRepository.findAll();
    }

    public HarvestRecord getById(String id) {
        return harvestRecordRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Harvest record not found with id: " + id));
    }

    public HarvestRecord update(String id, HarvestRequest request) {
        validateCrop(request.cropId());

        HarvestRecord harvestRecord = getById(id);
        harvestRecord.setCropId(request.cropId().trim());
        harvestRecord.setQuantity(request.quantity());
        harvestRecord.setHarvestDate(request.harvestDate());
        harvestRecord.setProductionRecord(request.productionRecord().trim());
        return harvestRecordRepository.save(harvestRecord);
    }

    public void delete(String id) {
        HarvestRecord harvestRecord = getById(id);
        harvestRecordRepository.delete(harvestRecord);
    }

    public List<HarvestRecord> getByCropId(String cropId) {
        validateCrop(cropId);
        return harvestRecordRepository.findByCropId(cropId);
    }

    private void validateCrop(String cropId) {
        if (!cropRepository.existsById(cropId.trim())) {
            throw new ResourceNotFoundException("Crop not found with id: " + cropId);
        }
    }
}

