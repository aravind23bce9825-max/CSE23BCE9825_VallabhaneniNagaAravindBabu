package com.smartagri.api.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.time.LocalDate;

public record HarvestRequest(
        @NotBlank(message = "Crop ID is required")
        String cropId,
        @NotNull(message = "Quantity is required")
        @Positive(message = "Quantity must be greater than zero")
        Double quantity,
        @NotNull(message = "Harvest date is required")
        LocalDate harvestDate,
        @NotBlank(message = "Production record is required")
        String productionRecord
) {
}

