package com.smartagri.api.service;

import com.smartagri.api.dto.FarmRequest;
import com.smartagri.api.exception.ConflictException;
import com.smartagri.api.exception.ResourceNotFoundException;
import com.smartagri.api.model.Crop;
import com.smartagri.api.model.Equipment;
import com.smartagri.api.model.Farm;
import com.smartagri.api.repository.CropRepository;
import com.smartagri.api.repository.EquipmentRepository;
import com.smartagri.api.repository.FarmRepository;
import com.smartagri.api.repository.FarmerRepository;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class FarmService {

    private final FarmRepository farmRepository;
    private final FarmerRepository farmerRepository;
    private final CropRepository cropRepository;
    private final EquipmentRepository equipmentRepository;

    public FarmService(
            FarmRepository farmRepository,
            FarmerRepository farmerRepository,
            CropRepository cropRepository,
            EquipmentRepository equipmentRepository
    ) {
        this.farmRepository = farmRepository;
        this.farmerRepository = farmerRepository;
        this.cropRepository = cropRepository;
        this.equipmentRepository = equipmentRepository;
    }

    public Farm create(FarmRequest request) {
        validateFarmer(request.farmerId());

        Farm farm = new Farm();
        farm.setFarmerId(request.farmerId().trim());
        farm.setFarmName(request.farmName().trim());
        farm.setLocation(request.location().trim());
        farm.setAreaInAcres(request.areaInAcres());
        farm.setEquipmentIds(new ArrayList<>());
        return farmRepository.save(farm);
    }

    public List<Farm> getAll() {
        return farmRepository.findAll();
    }

    public Farm getById(String id) {
        return farmRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Farm not found with id: " + id));
    }

    public Farm update(String id, FarmRequest request) {
        validateFarmer(request.farmerId());

        Farm existingFarm = getById(id);
        existingFarm.setFarmerId(request.farmerId().trim());
        existingFarm.setFarmName(request.farmName().trim());
        existingFarm.setLocation(request.location().trim());
        existingFarm.setAreaInAcres(request.areaInAcres());
        return farmRepository.save(existingFarm);
    }

    public void delete(String id) {
        Farm farm = getById(id);
        if (cropRepository.existsByFarmId(id)) {
            throw new ConflictException("Cannot delete farm because crops are linked to this farm.");
        }

        List<Equipment> equipments = equipmentRepository.findByFarmIdsContaining(id);
        for (Equipment equipment : equipments) {
            ensureFarmIds(equipment).remove(id);
            equipmentRepository.save(equipment);
        }

        farmRepository.delete(farm);
    }

    public List<Farm> getByFarmerId(String farmerId) {
        validateFarmer(farmerId);
        return farmRepository.findByFarmerId(farmerId);
    }

    public List<Crop> getCropsByFarmId(String farmId) {
        getById(farmId);
        return cropRepository.findByFarmId(farmId);
    }

    public List<Equipment> getEquipmentByFarmId(String farmId) {
        getById(farmId);
        return equipmentRepository.findByFarmIdsContaining(farmId);
    }

    public Farm assignEquipment(String farmId, String equipmentId) {
        Farm farm = getById(farmId);
        Equipment equipment = equipmentRepository.findById(equipmentId)
                .orElseThrow(() -> new ResourceNotFoundException("Equipment not found with id: " + equipmentId));

        List<String> equipmentIds = ensureEquipmentIds(farm);
        List<String> farmIds = ensureFarmIds(equipment);

        if (!equipmentIds.contains(equipmentId)) {
            equipmentIds.add(equipmentId);
        }
        if (!farmIds.contains(farmId)) {
            farmIds.add(farmId);
        }

        equipmentRepository.save(equipment);
        return farmRepository.save(farm);
    }

    public Farm removeEquipment(String farmId, String equipmentId) {
        Farm farm = getById(farmId);
        Equipment equipment = equipmentRepository.findById(equipmentId)
                .orElseThrow(() -> new ResourceNotFoundException("Equipment not found with id: " + equipmentId));

        ensureEquipmentIds(farm).remove(equipmentId);
        ensureFarmIds(equipment).remove(farmId);

        equipmentRepository.save(equipment);
        return farmRepository.save(farm);
    }

    private void validateFarmer(String farmerId) {
        if (!farmerRepository.existsById(farmerId.trim())) {
            throw new ResourceNotFoundException("Farmer not found with id: " + farmerId);
        }
    }

    private List<String> ensureEquipmentIds(Farm farm) {
        if (farm.getEquipmentIds() == null) {
            farm.setEquipmentIds(new ArrayList<>());
        }
        return farm.getEquipmentIds();
    }

    private List<String> ensureFarmIds(Equipment equipment) {
        if (equipment.getFarmIds() == null) {
            equipment.setFarmIds(new ArrayList<>());
        }
        return equipment.getFarmIds();
    }
}
