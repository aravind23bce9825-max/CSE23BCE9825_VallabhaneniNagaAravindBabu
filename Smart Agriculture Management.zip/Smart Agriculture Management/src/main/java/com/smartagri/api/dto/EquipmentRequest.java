package com.smartagri.api.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record EquipmentRequest(
        @NotBlank(message = "Equipment name is required")
        String equipmentName,
        @NotBlank(message = "Equipment type is required")
        String type,
        @NotNull(message = "Availability is required")
        Boolean available
) {
}

