package com.smartagri.api.repository;

import com.smartagri.api.model.Farmer;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface FarmerRepository extends MongoRepository<Farmer, String> {
}

