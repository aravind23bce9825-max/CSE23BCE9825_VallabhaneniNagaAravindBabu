package com.smartagri.api.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public record FarmRequest(
        @NotBlank(message = "Farmer ID is required")
        String farmerId,
        @NotBlank(message = "Farm name is required")
        String farmName,
        @NotBlank(message = "Location is required")
        String location,
        @NotNull(message = "Area in acres is required")
        @Positive(message = "Area in acres must be greater than zero")
        Double areaInAcres
) {
}

