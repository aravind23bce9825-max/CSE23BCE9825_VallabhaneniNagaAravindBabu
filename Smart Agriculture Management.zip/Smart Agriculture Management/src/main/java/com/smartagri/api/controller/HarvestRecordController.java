package com.smartagri.api.controller;

import com.smartagri.api.dto.HarvestRequest;
import com.smartagri.api.model.HarvestRecord;
import com.smartagri.api.service.HarvestRecordService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/harvests")
@Tag(name = "Harvests", description = "Operations related to harvest records")
public class HarvestRecordController {

    private final HarvestRecordService harvestRecordService;

    public HarvestRecordController(HarvestRecordService harvestRecordService) {
        this.harvestRecordService = harvestRecordService;
    }

    @PostMapping
    @Operation(summary = "Create a new harvest record")
    public ResponseEntity<HarvestRecord> create(@Valid @RequestBody HarvestRequest request) {
        HarvestRecord harvestRecord = harvestRecordService.create(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(harvestRecord);
    }

    @GetMapping
    @Operation(summary = "Get all harvest records")
    public List<HarvestRecord> getAll() {
        return harvestRecordService.getAll();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get harvest record by ID")
    public HarvestRecord getById(@PathVariable String id) {
        return harvestRecordService.getById(id);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update harvest record by ID")
    public HarvestRecord update(@PathVariable String id, @Valid @RequestBody HarvestRequest request) {
        return harvestRecordService.update(id, request);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete harvest record by ID")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        harvestRecordService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/crop/{cropId}")
    @Operation(summary = "Get harvest records by crop ID")
    public List<HarvestRecord> getByCropId(@PathVariable String cropId) {
        return harvestRecordService.getByCropId(cropId);
    }
}
