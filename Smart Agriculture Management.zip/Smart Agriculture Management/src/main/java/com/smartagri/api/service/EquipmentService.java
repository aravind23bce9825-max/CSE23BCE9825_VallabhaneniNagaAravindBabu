package com.smartagri.api.service;

import com.smartagri.api.dto.EquipmentRequest;
import com.smartagri.api.exception.ResourceNotFoundException;
import com.smartagri.api.model.Equipment;
import com.smartagri.api.model.Farm;
import com.smartagri.api.repository.EquipmentRepository;
import com.smartagri.api.repository.FarmRepository;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class EquipmentService {

    private final EquipmentRepository equipmentRepository;
    private final FarmRepository farmRepository;

    public EquipmentService(EquipmentRepository equipmentRepository, FarmRepository farmRepository) {
        this.equipmentRepository = equipmentRepository;
        this.farmRepository = farmRepository;
    }

    public Equipment create(EquipmentRequest request) {
        Equipment equipment = new Equipment();
        equipment.setEquipmentName(request.equipmentName().trim());
        equipment.setType(request.type().trim());
        equipment.setAvailable(request.available());
        equipment.setFarmIds(new ArrayList<>());
        return equipmentRepository.save(equipment);
    }

    public List<Equipment> getAll() {
        return equipmentRepository.findAll();
    }

    public Equipment getById(String id) {
        return equipmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Equipment not found with id: " + id));
    }

    public Equipment update(String id, EquipmentRequest request) {
        Equipment equipment = getById(id);
        equipment.setEquipmentName(request.equipmentName().trim());
        equipment.setType(request.type().trim());
        equipment.setAvailable(request.available());
        return equipmentRepository.save(equipment);
    }

    public void delete(String id) {
        Equipment equipment = getById(id);
        List<Farm> farms = farmRepository.findAll();
        for (Farm farm : farms) {
            if (farm.getEquipmentIds() != null && farm.getEquipmentIds().remove(id)) {
                farmRepository.save(farm);
            }
        }
        equipmentRepository.delete(equipment);
    }

    public List<Equipment> getByFarmId(String farmId) {
        if (!farmRepository.existsById(farmId.trim())) {
            throw new ResourceNotFoundException("Farm not found with id: " + farmId);
        }
        return equipmentRepository.findByFarmIdsContaining(farmId.trim());
    }
}
