package com.smartagri.api.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI smartAgricultureOpenApi() {
        return new OpenAPI().info(new Info()
                .title("Smart Agriculture Management API")
                .version("1.0")
                .description("REST API for managing farmers, farms, crops, equipment, and harvest records.")
                .contact(new Contact().name("Student Project")));
    }
}

