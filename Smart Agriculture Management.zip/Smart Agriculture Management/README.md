# Smart Agriculture Management API

Smart Agriculture Management API is a Spring Boot and MongoDB backend project for managing farmers, farms, crops, equipment, and harvest records through REST APIs.

## Tech Stack

- Java 17
- Spring Boot 3
- Spring Data MongoDB
- Spring Validation
- Swagger / OpenAPI
- Postman
- Maven

## Core Modules

- `Farmer`: farmer master data
- `Farm`: farm details linked to a farmer
- `Crop`: crop details linked to a farm
- `Equipment`: reusable equipment that can be assigned to multiple farms
- `HarvestRecord`: harvest entries linked to a crop

## Relationships

- One farmer -> many farms
- One farm -> many crops
- One crop -> many harvest records
- Many farms <-> many equipment items

## Project Structure

```text
src/main/java/com/smartagri/api
|- config
|- controller
|- dto
|- exception
|- model
|- repository
|- service
```

## Default Configuration

- Base URL: `http://localhost:8080`
- Swagger UI: `http://localhost:8080/swagger-ui.html`
- OpenAPI JSON: `http://localhost:8080/api-docs`
- MongoDB URI: `mongodb://localhost:27017/smart_agriculture_api_db`

You can override these values with:

- `MONGODB_URI`
- `SERVER_PORT`

## How To Execute The Project

### Option 1: Run with local MongoDB

1. Make sure MongoDB is installed and running on `localhost:27017`.
2. Open a terminal in the project folder:

```powershell
cd "C:\Coding Practice\SmartAgricultureManagementApi"
```

3. Start the Spring Boot application:

```powershell
mvn spring-boot:run
```

4. Open Swagger UI in the browser:

```text
http://localhost:8080/swagger-ui.html
```

### Option 2: Run MongoDB using Docker

1. Start MongoDB with Docker Compose:

```powershell
docker compose up -d
```

2. Run the Spring Boot application:

```powershell
mvn spring-boot:run
```

3. Stop MongoDB when you are done:

```powershell
docker compose down
```

## How To Build A JAR

```powershell
mvn clean package
java -jar target/smart-agriculture-management-api-1.0.0.jar
```

## API Endpoints

### Farmers

- `POST /api/farmers`
- `GET /api/farmers`
- `GET /api/farmers/{id}`
- `PUT /api/farmers/{id}`
- `DELETE /api/farmers/{id}`
- `GET /api/farmers/{id}/farms`

### Farms

- `POST /api/farms`
- `GET /api/farms`
- `GET /api/farms/{id}`
- `PUT /api/farms/{id}`
- `DELETE /api/farms/{id}`
- `GET /api/farms/farmer/{farmerId}`
- `GET /api/farms/{id}/crops`
- `GET /api/farms/{id}/equipment`
- `POST /api/farms/{farmId}/equipment/{equipmentId}`
- `DELETE /api/farms/{farmId}/equipment/{equipmentId}`

### Crops

- `POST /api/crops`
- `GET /api/crops`
- `GET /api/crops/{id}`
- `PUT /api/crops/{id}`
- `DELETE /api/crops/{id}`
- `GET /api/crops/farm/{farmId}`
- `GET /api/crops/{id}/harvests`

### Equipment

- `POST /api/equipment`
- `GET /api/equipment`
- `GET /api/equipment/{id}`
- `PUT /api/equipment/{id}`
- `DELETE /api/equipment/{id}`
- `GET /api/equipment/farm/{farmId}`

### Harvest Records

- `POST /api/harvests`
- `GET /api/harvests`
- `GET /api/harvests/{id}`
- `PUT /api/harvests/{id}`
- `DELETE /api/harvests/{id}`
- `GET /api/harvests/crop/{cropId}`

## Testing The API

- Import [SmartAgricultureManagementApi.postman_collection.json](/c:/Coding%20Practice/SmartAgricultureManagementApi/SmartAgricultureManagementApi.postman_collection.json) into Postman.
- Use [POSTMAN_AND_API_GUIDE.md](/c:/Coding%20Practice/SmartAgricultureManagementApi/POSTMAN_AND_API_GUIDE.md) for the demo request order.
- You can also test every endpoint directly from Swagger UI.

## Suggested Demo Flow

1. Create a farmer.
2. Create a farm using the farmer ID.
3. Create a crop using the farm ID.
4. Create equipment.
5. Assign equipment to the farm.
6. Create a harvest record using the crop ID.
7. Use the GET endpoints to show the linked data.
